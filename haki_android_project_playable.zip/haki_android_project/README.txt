HAKI OFFLINE ANDROID PROJECT - BUILD DEBUG APK

This project is ready to build on GitHub Actions. A APK has NOT yet been compiled.

BUILD IT (requires a GitHub account):
1. Open https://github.com/new and create a repository (public/private is fine).
2. On the repository page choose Add file > Upload files.
3. Extract this ZIP on your phone/computer and upload the CONTENTS of the haki_android_project folder (including .github folder). If .github is hidden, make sure the workflow file is uploaded too.
4. Commit the uploaded files.
5. Open the repository's Actions tab. Choose "Build APK" workflow on the left, click "Run workflow", then confirm.
6. Wait for the workflow to finish green. Open the completed run and download the artifact named HakiOfflineAPK.
7. Extract the downloaded artifact ZIP; install the .apk on Android (allow install from unknown sources if prompted).

The APK is an offline HTML/WebView prototype wrapper, not a restored original game.
